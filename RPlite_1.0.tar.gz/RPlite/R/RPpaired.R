RPpaired <-
function (m, nperms = 200, method=c("gamma","permutation","geometricLU")) {
    Ngenes <- nrow(m)
    Nsamplepairs <- ncol(m)
    ranks <- apply(m, 2, function(x) rank(x))
    if(method[1]=="permutation")
      {
        ##        ranks<--log(ranks/(1+Ngenes-ranks))
        ranks<--log(ranks)
        scores<-rowSums(ranks)
        nulld <- unlist(lapply(1:nperms,function(x)
                               {
                                 rowSums(apply(ranks,2,sample))
                               }))
        fr <-compute.Stats(nulld, scores, Ngenes, nperms)
      }
    if(method[1]=="gamma")
      {
        scores <- -rowSums(log(ranks)) + ncol(m) * log(Ngenes + 1)
        nulld <- rgamma(Ngenes * nperms, shape = Nsamplepairs, scale = 1)
        fr <- compute.Stats(nulld, scores, Ngenes, nperms)
      }
    if(method[1]=="geometricLU")
      {
        scores <- apply(ranks,1,prod)
        nulld<-NULL
        fr<-list()
        err<-try(fr$pvals.do<-rankprodbounds(scores,n=Ngenes,k=ncol(m),Delta="geometric"), silent=F)
        if(sum(grepl("Error",unlist(err)))>0) print("Please, consider using method permutation or gamma instead of geomeitrcLU") 
        fr$pvals.up<-1-fr$pvals.do
        fr$qvals.do<-p.adjust(fr$pvals.do,method="fdr")
        fr$qvals.up<-p.adjust(fr$pvals.up,method="fdr")
        fr$scores <- scores
      }
    return(list(lStats = fr, null.distrib = list(nulld), final.scores = list(scores), 
                nperms = nperms))
}
